# 口红颜色可视化

为什么你的女神总缺一支口红？

因为口红居然有这么多颜色！[去看看！](http://zhangwenli.com/lipstick/)

![截图](assets/screenshot.png)
